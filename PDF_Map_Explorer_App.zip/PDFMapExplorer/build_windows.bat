@echo off
setlocal
cd /d "%~dp0"
py -3.11 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
pyinstaller --noconfirm --clean --onefile --windowed ^
  --name "PDFMapExplorer" ^
  --icon "assets\app.ico" ^
  --add-data "assets\app.ico;assets" ^
  --collect-all fitz ^
  main.py

echo.
echo Build finished. EXE: %CD%\dist\PDFMapExplorer.exe
pause
