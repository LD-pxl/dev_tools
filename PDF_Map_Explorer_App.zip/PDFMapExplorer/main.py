from __future__ import annotations

import math
import os
import sys
import traceback
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

import fitz  # PyMuPDF
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from PySide6.QtCore import QObject, QThread, Qt, Signal
from PySide6.QtGui import QColor, QIcon
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QFileDialog, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QMainWindow, QMessageBox, QProgressBar, QPushButton,
    QTabWidget, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget
)

APP_NAME = "PDF Map Explorer"
COMMENT_COLUMNS = [
    "orientation", "page", "rect", "color", "creationdate", "modifydate",
    "name", "subject", "title", "flags", "style", "defaultappearance",
    "defaultstyle", "annotation"
]
SYMBOL_COLUMNS = [
    "page", "name", "subject", "title", "color", "interior_color",
    "start_point", "end_point", "head", "tail", "rect", "flags",
    "creationdate", "modifydate", "popup_rect", "popup_page", "popup_open",
    "popup_flags"
]
COMMENT_TYPES = {
    "Text", "FreeText", "Highlight", "Underline", "Squiggly", "StrikeOut",
    "Redact", "Caret"
}
SYMBOL_TYPES = {
    "Line", "Square", "Circle", "Polygon", "PolyLine", "Stamp", "Ink",
    "FileAttachment", "Sound", "Movie", "Screen", "PrinterMark", "TrapNet",
    "Watermark", "3D", "Projection"
}


def resource_path(relative: str) -> str:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return str(base / relative)


def safe_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return ", ".join(safe_text(v) for v in value)
    return str(value)


def fmt_num(value: Any) -> str:
    try:
        num = float(value)
        if math.isfinite(num):
            return f"{num:.4f}".rstrip("0").rstrip(".")
    except (TypeError, ValueError):
        pass
    return safe_text(value)


def fmt_rect(rect: Any) -> str:
    if rect is None:
        return ""
    try:
        return ",".join(fmt_num(v) for v in (rect.x0, rect.y0, rect.x1, rect.y1))
    except Exception:
        return safe_text(rect)


def fmt_point(point: Any) -> str:
    if point is None:
        return ""
    try:
        return f"{fmt_num(point.x)},{fmt_num(point.y)}"
    except Exception:
        try:
            return f"{fmt_num(point[0])},{fmt_num(point[1])}"
        except Exception:
            return safe_text(point)


def fmt_color(color: Any) -> str:
    if color in (None, [], ()): return ""
    try:
        vals = list(color)
        if not vals: return ""
        rgb = vals[:3] if len(vals) >= 3 else vals * 3
        rgb = [max(0, min(255, round(float(v) * 255))) for v in rgb[:3]]
        return "#{:02X}{:02X}{:02X}".format(*rgb)
    except Exception:
        return safe_text(color)


def pdf_date_to_text(value: str) -> str:
    if not value: return ""
    raw = value[2:] if value.startswith("D:") else value
    digits = "".join(c for c in raw[:14] if c.isdigit())
    try:
        parts = [int(digits[0:4]), int(digits[4:6] or 1), int(digits[6:8] or 1),
                 int(digits[8:10] or 0), int(digits[10:12] or 0), int(digits[12:14] or 0)]
        return datetime(*parts).isoformat(sep=" ")
    except Exception:
        return value


def annotation_type(annot: fitz.Annot) -> str:
    try: return safe_text(annot.type[1])
    except Exception: return "Unknown"


def opacity_or_style(annot: fitz.Annot) -> str:
    bits = []
    try:
        opacity = annot.opacity
        if opacity is not None and opacity >= 0: bits.append(f"opacity={fmt_num(opacity)}")
    except Exception: pass
    try:
        border = annot.border or {}
        if border: bits.append("border=" + safe_text(border))
    except Exception: pass
    return "; ".join(bits)


def extract_pdf(pdf_path: Path, progress=None) -> tuple[list[dict], list[dict]]:
    comments: list[dict] = []
    symbols: list[dict] = []
    doc = fitz.open(pdf_path)
    try:
        total = max(1, doc.page_count)
        for pno in range(doc.page_count):
            page = doc[pno]
            rotation = page.rotation
            annots = list(page.annots() or [])
            for annot in annots:
                kind = annotation_type(annot)
                info = annot.info or {}
                colors = annot.colors or {}
                base = {
                    "page": pno + 1,
                    "name": info.get("name", kind),
                    "subject": info.get("subject", ""),
                    "title": info.get("title", ""),
                    "color": fmt_color(colors.get("stroke")),
                    "rect": fmt_rect(annot.rect),
                    "flags": safe_text(annot.flags),
                    "creationdate": pdf_date_to_text(info.get("creationDate", "")),
                    "modifydate": pdf_date_to_text(info.get("modDate", "")),
                }
                content = info.get("content", "")
                if kind in COMMENT_TYPES or content:
                    comments.append({
                        "orientation": rotation,
                        **base,
                        "style": opacity_or_style(annot),
                        "defaultappearance": info.get("defaultAppearance", ""),
                        "defaultstyle": info.get("defaultStyle", ""),
                        "annotation": content,
                    })
                if kind in SYMBOL_TYPES:
                    vertices = []
                    try: vertices = list(annot.vertices or [])
                    except Exception: pass
                    start = vertices[0] if vertices else None
                    end = vertices[-1] if len(vertices) > 1 else None
                    head = tail = ""
                    try:
                        line_ends = annot.line_ends
                        if line_ends:
                            head, tail = map(safe_text, line_ends)
                    except Exception: pass
                    popup_rect = ""
                    popup_page = ""
                    popup_open = ""
                    popup_flags = ""
                    try:
                        popup = annot.popup
                        if popup:
                            popup_rect = fmt_rect(popup.rect)
                            popup_page = popup.parent.number + 1
                            popup_flags = safe_text(popup.flags)
                            popup_open = safe_text((popup.info or {}).get("open", ""))
                    except Exception: pass
                    symbols.append({
                        **base,
                        "interior_color": fmt_color(colors.get("fill")),
                        "start_point": fmt_point(start),
                        "end_point": fmt_point(end),
                        "head": head,
                        "tail": tail,
                        "popup_rect": popup_rect,
                        "popup_page": popup_page,
                        "popup_open": popup_open,
                        "popup_flags": popup_flags,
                    })
            if progress: progress(int((pno + 1) / total * 55))
    finally:
        doc.close()
    return comments, symbols


def write_excel(path: Path, sheet_name: str, columns: list[str], rows: list[dict]) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name
    ws.append(columns)
    header_fill = PatternFill("solid", fgColor="1769E0")
    for cell in ws[1]:
        cell.font = Font(color="FFFFFF", bold=True)
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center")
    for row in rows:
        ws.append([row.get(c, "") for c in columns])
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for idx, col in enumerate(columns, 1):
        values = [safe_text(ws.cell(r, idx).value) for r in range(1, min(ws.max_row, 300) + 1)]
        width = min(55, max(11, max((len(v) for v in values), default=10) + 2))
        ws.column_dimensions[get_column_letter(idx)].width = width
    wb.save(path)


def write_xfdf(path: Path, comments: list[dict], symbols: list[dict]) -> None:
    ns = "http://ns.adobe.com/xfdf/"
    ET.register_namespace("", ns)
    root = ET.Element(f"{{{ns}}}xfdf")
    annots = ET.SubElement(root, f"{{{ns}}}annots")
    for row in comments:
        node = ET.SubElement(annots, f"{{{ns}}}freetext", {
            "page": str(max(0, int(row["page"]) - 1)), "rect": row["rect"],
            "color": row["color"], "creationdate": row["creationdate"],
            "date": row["modifydate"], "name": row["name"],
            "subject": row["subject"], "title": row["title"],
            "flags": row["flags"], "style": row["style"],
            "defaultappearance": row["defaultappearance"],
            "defaultstyle": row["defaultstyle"], "orientation": safe_text(row["orientation"]),
        })
        contents = ET.SubElement(node, f"{{{ns}}}contents")
        contents.text = row["annotation"]
    for row in symbols:
        node = ET.SubElement(annots, f"{{{ns}}}symbol", {k: safe_text(row.get(k, "")) for k in SYMBOL_COLUMNS})
        node.set("page", str(max(0, int(row["page"]) - 1)))
    ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)


def write_sas_xmlmap(path: Path) -> None:
    # SAS XMLMap for the XFDF produced by this application.
    xml = '''<?xml version="1.0" encoding="UTF-8"?>
<SXLEMAP version="2.1">
  <NAMESPACES count="1"><NS id="1" prefix="xfdf">http://ns.adobe.com/xfdf/</NS></NAMESPACES>
  <TABLE name="COMMENTS">
    <TABLE-PATH syntax="XPathENR">/xfdf:xfdf/xfdf:annots/xfdf:freetext</TABLE-PATH>
%s
    <COLUMN name="annotation"><PATH syntax="XPathENR">/xfdf:xfdf/xfdf:annots/xfdf:freetext/xfdf:contents</PATH><TYPE>character</TYPE><DATATYPE>string</DATATYPE><LENGTH>4000</LENGTH></COLUMN>
  </TABLE>
  <TABLE name="SYMBOLS">
    <TABLE-PATH syntax="XPathENR">/xfdf:xfdf/xfdf:annots/xfdf:symbol</TABLE-PATH>
%s
  </TABLE>
</SXLEMAP>
'''
    comment_cols = [c for c in COMMENT_COLUMNS if c != "annotation"]
    def cols(names):
        return "\n".join(
            f'    <COLUMN name="{n}"><PATH syntax="XPathENR">{{ATTRIBUTE}}{n}</PATH><TYPE>character</TYPE><DATATYPE>string</DATATYPE><LENGTH>1000</LENGTH></COLUMN>'
            for n in names
        )
    path.write_text(xml % (cols(comment_cols), cols(SYMBOL_COLUMNS)), encoding="utf-8")


@dataclass
class JobOptions:
    pdf: Path
    output: Path
    make_map: bool
    export_comments: bool
    export_symbols: bool


class Worker(QObject):
    progress = Signal(int)
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, options: JobOptions):
        super().__init__(); self.options = options

    def run(self):
        try:
            o = self.options
            o.output.mkdir(parents=True, exist_ok=True)
            comments, symbols = extract_pdf(o.pdf, self.progress.emit)
            files = []
            stem = o.pdf.stem
            if o.make_map:
                xfdf = o.output / f"{stem}_annotations.xfdf"
                smap = o.output / f"{stem}_annotations.map"
                write_xfdf(xfdf, comments, symbols); write_sas_xmlmap(smap)
                files += [xfdf, smap]
            self.progress.emit(70)
            if o.export_comments:
                p = o.output / f"{stem}_comments.xlsx"; write_excel(p, "Comments", COMMENT_COLUMNS, comments); files.append(p)
            self.progress.emit(85)
            if o.export_symbols:
                p = o.output / f"{stem}_symbols.xlsx"; write_excel(p, "Symbols", SYMBOL_COLUMNS, symbols); files.append(p)
            self.progress.emit(100)
            self.done.emit({"comments": comments, "symbols": symbols, "files": files})
        except Exception:
            self.failed.emit(traceback.format_exc())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        icon = resource_path("assets/app.ico")
        if Path(icon).exists(): self.setWindowIcon(QIcon(icon))
        self.resize(1120, 760)
        self.result = {"comments": [], "symbols": [], "files": []}
        self.thread = None
        self.worker = None
        self.build_ui()

    def build_ui(self):
        root = QWidget(); self.setCentralWidget(root)
        outer = QVBoxLayout(root); outer.setContentsMargins(22, 20, 22, 20); outer.setSpacing(14)
        header = QFrame(); header.setObjectName("header")
        hl = QHBoxLayout(header); hl.setContentsMargins(22, 18, 22, 18)
        badge = QLabel("PDF"); badge.setObjectName("badge"); badge.setAlignment(Qt.AlignCenter); badge.setFixedSize(60, 60)
        title_box = QVBoxLayout(); title = QLabel(APP_NAME); title.setObjectName("title")
        sub = QLabel("Generate SAS XMLMap/XFDF files and export PDF comments or drawing symbols to Excel."); sub.setObjectName("subtitle")
        title_box.addWidget(title); title_box.addWidget(sub)
        hl.addWidget(badge); hl.addLayout(title_box); hl.addStretch(); outer.addWidget(header)

        card = QFrame(); card.setObjectName("card"); grid = QGridLayout(card); grid.setContentsMargins(22, 22, 22, 22); grid.setHorizontalSpacing(12); grid.setVerticalSpacing(14)
        grid.addWidget(QLabel("1  PDF document"), 0, 0, 1, 3)
        self.pdf_edit = QLineEdit(); self.pdf_edit.setPlaceholderText("Choose a PDF that contains annotations...")
        browse_pdf = QPushButton("Browse PDF"); browse_pdf.clicked.connect(self.pick_pdf)
        grid.addWidget(self.pdf_edit, 1, 0, 1, 2); grid.addWidget(browse_pdf, 1, 2)
        grid.addWidget(QLabel("2  Output folder"), 2, 0, 1, 3)
        self.out_edit = QLineEdit(); self.out_edit.setPlaceholderText("Results will be saved here...")
        browse_out = QPushButton("Browse folder"); browse_out.clicked.connect(self.pick_output)
        grid.addWidget(self.out_edit, 3, 0, 1, 2); grid.addWidget(browse_out, 3, 2)
        grid.addWidget(QLabel("3  Choose outputs"), 4, 0, 1, 3)
        self.map_cb = QCheckBox("SAS XMLMap + XFDF annotation data"); self.map_cb.setChecked(True)
        self.comments_cb = QCheckBox("Comments Excel"); self.comments_cb.setChecked(True)
        self.symbols_cb = QCheckBox("Symbols Excel"); self.symbols_cb.setChecked(True)
        checks = QHBoxLayout(); checks.addWidget(self.map_cb); checks.addWidget(self.comments_cb); checks.addWidget(self.symbols_cb); checks.addStretch()
        grid.addLayout(checks, 5, 0, 1, 3); outer.addWidget(card)

        actions = QHBoxLayout(); self.run_btn = QPushButton("Start processing"); self.run_btn.setObjectName("primary"); self.run_btn.clicked.connect(self.start)
        self.open_btn = QPushButton("Open output folder"); self.open_btn.setEnabled(False); self.open_btn.clicked.connect(self.open_output)
        actions.addWidget(self.run_btn); actions.addWidget(self.open_btn); actions.addStretch(); outer.addLayout(actions)
        self.progress = QProgressBar(); self.progress.setValue(0); outer.addWidget(self.progress)
        self.status = QLabel("Ready. Select a PDF to begin."); self.status.setObjectName("status"); outer.addWidget(self.status)

        self.tabs = QTabWidget(); self.comment_table = QTableWidget(); self.symbol_table = QTableWidget(); self.log = QTextEdit(); self.log.setReadOnly(True)
        self.tabs.addTab(self.comment_table, "Comments preview"); self.tabs.addTab(self.symbol_table, "Symbols preview"); self.tabs.addTab(self.log, "Processing log")
        outer.addWidget(self.tabs, 1)
        self.apply_style()

    def apply_style(self):
        self.setStyleSheet('''
        QWidget { font-family: "Segoe UI", Arial; font-size: 13px; color: #172033; background: #f4f7fb; }
        QFrame#header { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #eaf3ff,stop:1 #f6f0ff); border: 1px solid #d9e5f3; border-radius: 16px; }
        QFrame#card { background: white; border: 1px solid #dce5f0; border-radius: 14px; }
        QLabel#badge { color: white; background: #ef4637; border-radius: 14px; font-weight: 800; font-size: 18px; }
        QLabel#title { font-size: 28px; font-weight: 750; color: #0f1d36; background: transparent; }
        QLabel#subtitle { color: #607089; background: transparent; }
        QLabel#status { color: #52627a; padding: 4px; }
        QLineEdit { background: #fbfdff; border: 1px solid #cbd7e6; border-radius: 8px; padding: 10px; selection-background-color: #1769e0; }
        QPushButton { background: white; border: 1px solid #bfcde0; border-radius: 8px; padding: 10px 16px; font-weight: 600; }
        QPushButton:hover { background: #edf5ff; border-color: #1769e0; }
        QPushButton#primary { background: #1769e0; color: white; border: none; padding: 12px 24px; }
        QPushButton#primary:hover { background: #0e5ccc; }
        QPushButton:disabled { color: #94a0b2; background: #edf0f5; }
        QProgressBar { background: #e9eef5; border: none; border-radius: 6px; height: 12px; text-align: center; }
        QProgressBar::chunk { background: #2aa56b; border-radius: 6px; }
        QTabWidget::pane { background: white; border: 1px solid #dce5f0; border-radius: 8px; }
        QTabBar::tab { background: #e9eef5; padding: 9px 16px; margin-right: 3px; border-top-left-radius: 7px; border-top-right-radius: 7px; }
        QTabBar::tab:selected { background: white; color: #1769e0; }
        QTableWidget, QTextEdit { background: white; border: none; gridline-color: #e3e9f1; }
        QHeaderView::section { background: #eef4fb; padding: 7px; border: none; border-right: 1px solid #d8e1ec; font-weight: 700; }
        ''')

    def pick_pdf(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select PDF", "", "PDF documents (*.pdf)")
        if path:
            self.pdf_edit.setText(path)
            if not self.out_edit.text(): self.out_edit.setText(str(Path(path).parent / f"{Path(path).stem}_results"))

    def pick_output(self):
        path = QFileDialog.getExistingDirectory(self, "Select output folder")
        if path: self.out_edit.setText(path)

    def start(self):
        pdf = Path(self.pdf_edit.text().strip())
        out = Path(self.out_edit.text().strip()) if self.out_edit.text().strip() else Path()
        if not pdf.is_file() or pdf.suffix.lower() != ".pdf":
            QMessageBox.warning(self, APP_NAME, "Please select a valid PDF document."); return
        if not self.map_cb.isChecked() and not self.comments_cb.isChecked() and not self.symbols_cb.isChecked():
            QMessageBox.warning(self, APP_NAME, "Select at least one output option."); return
        if not str(out): QMessageBox.warning(self, APP_NAME, "Please select an output folder."); return
        self.run_btn.setEnabled(False); self.open_btn.setEnabled(False); self.progress.setValue(0)
        self.status.setText("Reading PDF annotations..."); self.log.clear()
        options = JobOptions(pdf, out, self.map_cb.isChecked(), self.comments_cb.isChecked(), self.symbols_cb.isChecked())
        self.thread = QThread(); self.worker = Worker(options); self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run); self.worker.progress.connect(self.progress.setValue)
        self.worker.done.connect(self.finished); self.worker.failed.connect(self.failed)
        self.worker.done.connect(self.thread.quit); self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.worker.deleteLater); self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def finished(self, result):
        self.result = result; self.run_btn.setEnabled(True); self.open_btn.setEnabled(True)
        self.status.setText(f"Completed: {len(result['comments'])} comment records and {len(result['symbols'])} symbol records.")
        self.fill_table(self.comment_table, COMMENT_COLUMNS, result["comments"])
        self.fill_table(self.symbol_table, SYMBOL_COLUMNS, result["symbols"])
        self.log.setPlainText("Created files:\n" + "\n".join(str(p) for p in result["files"]))
        QMessageBox.information(self, APP_NAME, "Processing completed successfully.")

    def failed(self, detail):
        self.run_btn.setEnabled(True); self.progress.setValue(0); self.status.setText("Processing failed. See the log for details.")
        self.log.setPlainText(detail); self.tabs.setCurrentWidget(self.log)
        QMessageBox.critical(self, APP_NAME, "The PDF could not be processed. See Processing log for details.")

    @staticmethod
    def fill_table(table, columns, rows):
        preview = rows[:500]
        table.clear(); table.setColumnCount(len(columns)); table.setHorizontalHeaderLabels(columns); table.setRowCount(len(preview))
        for r, row in enumerate(preview):
            for c, name in enumerate(columns): table.setItem(r, c, QTableWidgetItem(safe_text(row.get(name, ""))))
        table.resizeColumnsToContents()

    def open_output(self):
        out = Path(self.out_edit.text())
        if out.exists():
            if sys.platform == "win32": os.startfile(str(out))
            elif sys.platform == "darwin": os.system(f'open "{out}"')
            else: os.system(f'xdg-open "{out}" >/dev/null 2>&1 &')


def main():
    app = QApplication(sys.argv); app.setApplicationName(APP_NAME)
    win = MainWindow(); win.show(); sys.exit(app.exec())

if __name__ == "__main__": main()
