@echo off
py -m pip install --upgrade pyinstaller
py -m PyInstaller --noconfirm --clean --onefile --windowed --name FileListCopier file_list_copier.py
echo.
echo EXE created at dist\FileListCopier.exe
pause
