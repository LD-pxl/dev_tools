import os, shutil, threading, tkinter as tk, fnmatch
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

APP='File List Copier'

class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title(APP); self.geometry('820x650'); self.minsize(700,560)
        self.source=tk.StringVar(); self.dest=tk.StringVar(); self.recursive=tk.BooleanVar(value=False)
        self.case_ins=tk.BooleanVar(value=True); self.exists=tk.StringVar(value='Skip')
        self._ui()
    def _ui(self):
        p=ttk.Frame(self,padding=14); p.pack(fill='both',expand=True)
        ttk.Label(p,text=APP,font=('Segoe UI',16,'bold')).pack(anchor='w')
        ttk.Label(p,text='Copy one or more named files from a source folder to a destination folder.').pack(anchor='w',pady=(2,12))
        self._folder(p,'Source folder',self.source)
        self._folder(p,'Destination folder',self.dest)
        ttk.Label(p,text='File names or wildcard patterns (one per line)').pack(anchor='w',pady=(10,4))
        self.names=tk.Text(p,height=11,wrap='none'); self.names.pack(fill='both',expand=True)
        ttk.Label(p,text='Paste from Excel or enter patterns such as t_14_*.rtf, ae_??.sas7bdat, or *.pdf. Blank lines and duplicates are ignored.').pack(anchor='w',pady=(4,8))
        o=ttk.Frame(p); o.pack(fill='x')
        ttk.Checkbutton(o,text='Search subfolders',variable=self.recursive).pack(side='left',padx=(0,18))
        ttk.Checkbutton(o,text='Case-insensitive matching',variable=self.case_ins).pack(side='left')
        e=ttk.Frame(p); e.pack(fill='x',pady=(10,0)); ttk.Label(e,text='If destination file exists:').pack(side='left')
        ttk.Combobox(e,textvariable=self.exists,values=['Skip','Overwrite','Rename'],state='readonly',width=12).pack(side='left',padx=8)
        b=ttk.Frame(p); b.pack(fill='x',pady=12)
        self.copybtn=ttk.Button(b,text='Copy Files',command=self.start); self.copybtn.pack(side='left')
        ttk.Button(b,text='Clear Results',command=lambda:self.results.delete('1.0','end')).pack(side='left',padx=8)
        self.status=tk.StringVar(value='Ready.'); ttk.Label(p,textvariable=self.status).pack(anchor='w')
        self.results=tk.Text(p,height=10,state='normal',wrap='word'); self.results.pack(fill='both',expand=True,pady=(5,0))
    def _folder(self,p,label,var):
        ttk.Label(p,text=label).pack(anchor='w',pady=(8,4)); r=ttk.Frame(p); r.pack(fill='x')
        ttk.Entry(r,textvariable=var).pack(side='left',fill='x',expand=True)
        ttk.Button(r,text='Browse...',command=lambda:self.pick(var)).pack(side='left',padx=(8,0))
    def pick(self,var):
        x=filedialog.askdirectory();
        if x: var.set(x)
    def log(self,s): self.results.insert('end',s+'\n'); self.results.see('end')
    def start(self):
        src=Path(self.source.get().strip()); dst=Path(self.dest.get().strip())
        raw=[x.strip().strip('"') for x in self.names.get('1.0','end').splitlines() if x.strip()]
        names=list(dict.fromkeys(raw))
        if not src.is_dir(): return messagebox.showerror(APP,'Please select a valid source folder.')
        if not str(dst): return messagebox.showerror(APP,'Please select a destination folder.')
        if not names: return messagebox.showerror(APP,'Please enter at least one file name.')
        try: dst.mkdir(parents=True,exist_ok=True)
        except Exception as e: return messagebox.showerror(APP,f'Cannot create/access destination folder:\n{e}')
        self.copybtn.config(state='disabled'); self.results.delete('1.0','end'); self.status.set('Working...')
        threading.Thread(target=self.run_copy,args=(src,dst,names),daemon=True).start()
    def run_copy(self,src,dst,names):
        try:
            files=[]
            iterator=src.rglob('*') if self.recursive.get() else src.iterdir()
            for f in iterator:
                if f.is_file(): files.append(f)
            copied=missing=skipped=failed=0
            selected={}
            for pattern in names:
                check_pattern=pattern.lower() if self.case_ins.get() else pattern
                matches=[]
                for f in files:
                    check_name=f.name.lower() if self.case_ins.get() else f.name
                    if fnmatch.fnmatchcase(check_name, check_pattern): matches.append(f)
                if not matches:
                    missing+=1; self.after(0,self.log,f'NOT FOUND: {pattern}'); continue
                self.after(0,self.log,f'MATCHED {len(matches)}: {pattern}')
                for f in matches:
                    key=str(f.resolve()).lower() if self.case_ins.get() else str(f.resolve())
                    selected[key]=f
            for f in selected.values():
                target=dst/f.name
                try:
                    if target.exists():
                        mode=self.exists.get()
                        if mode=='Skip': skipped+=1; self.after(0,self.log,f'SKIPPED EXISTS: {target.name}'); continue
                        if mode=='Rename':
                            stem,suf=target.stem,target.suffix; i=1
                            while target.exists(): target=dst/f'{stem}_{i}{suf}'; i+=1
                    shutil.copy2(f,target); copied+=1; self.after(0,self.log,f'COPIED: {f.name} -> {target}')
                except Exception as e: failed+=1; self.after(0,self.log,f'FAILED: {f.name}: {e}')
            summary=f'Done: {len(names)} patterns | {len(selected)} unique files matched | {copied} copied | {missing} unmatched patterns | {skipped} skipped | {failed} failed'
            self.after(0,self.status.set,summary); self.after(0,self.log,summary)
        except Exception as e:
            self.after(0,self.status.set,'Stopped due to an error.'); self.after(0,self.log,f'ERROR: {e}')
        finally: self.after(0,lambda:self.copybtn.config(state='normal'))

if __name__=='__main__': App().mainloop()
