File List Copier - Wildcard Edition
===================================
Copy exact filenames or wildcard filename patterns from a source folder to a destination folder.

Supported patterns:
  adae.sas7bdat   exact filename
  t_14_*.rtf      * matches any sequence of characters
  ae_??.sas7bdat  ? matches exactly one character per ?
  *.pdf           all PDF filenames

Options:
- Search subfolders
- Case-insensitive matching
- Existing destination file: Skip / Overwrite / Rename
- Duplicate matches from overlapping patterns are copied only once

Build on Windows:
1. Install Python 3.x and select Add Python to PATH.
2. Extract this ZIP.
3. Double-click build_windows.bat.
4. Find the executable at dist\FileListCopier.exe.
